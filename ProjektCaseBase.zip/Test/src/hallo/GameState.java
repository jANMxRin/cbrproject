package hallo;

public class GameState {
	public int spielerHand;
	public String spielerFeld1; 
	public String spielerFeld2;
	public String spielerFeld3;
	public boolean spielerRausgekommen;

	public String cpuHand;
	public String cpuFeld1; 
	public String cpuFeld2;
	public String cpuFeld3;
	public boolean cpuRausgekommen;
	public String abwurfStapel;
	
	public GameState(int spielerHand, String spielerFeld1, String spielerFeld2, String spielerFeld3, boolean spielerRausgekommen,
			String cpuHand, String cpuFeld1, String cpuFeld2, String cpuFeld3, boolean cpuRausgekommen, 
			 String abwurfStapel) {
		this.spielerHand = spielerHand;
		this.spielerFeld1 = spielerFeld1;
		this.spielerFeld2 = spielerFeld2;
		this.spielerFeld3 = spielerFeld3;
		this.spielerRausgekommen = spielerRausgekommen;
		this.cpuHand = cpuHand;
		this.cpuFeld1 = cpuFeld1;
		this.cpuFeld2 = cpuFeld2;
		this.cpuFeld3 = cpuFeld3;
		this.cpuRausgekommen = cpuRausgekommen;
		
		this.abwurfStapel = abwurfStapel;
	}

	public int getSpielerHand() {
		return spielerHand;
	}

	public String getSpielerFeld1() {
		return spielerFeld1;
	}

	public String getSpielerFeld2() {
		return spielerFeld2;
	}

	public String getSpielerFeld3() {
		return spielerFeld3;
	}


	public boolean getSpielerRausgekommen() {
		return spielerRausgekommen;
	}


	public String getCpuHand() {
		return cpuHand;
	}

	public String getCpuFeld1() {
		return cpuFeld1;
	}

	public String getCpuFeld2() {
		return cpuFeld2;
	}

	public String getCpuFeld3() {
		return cpuFeld3;
	}

	public boolean getCpuRausgekommen() {
		return cpuRausgekommen;
	}

	public String getAbwurfStapel() {
		return abwurfStapel;
	}

}


