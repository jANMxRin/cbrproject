package hallo;


import java.util.ArrayList;
import java.util.List;
import java.text.ParseException;

import de.dfki.mycbr.core.casebase.Instance;
import de.dfki.mycbr.core.model.Concept;
import de.dfki.mycbr.core.model.IntegerDesc;
import de.dfki.mycbr.core.model.SymbolDesc;
import de.dfki.mycbr.core.retrieval.Retrieval;
import de.dfki.mycbr.core.retrieval.Retrieval.RetrievalMethod;
import de.dfki.mycbr.core.similarity.Similarity;
import de.dfki.mycbr.core.*;
import de.dfki.mycbr.util.Pair;





public class CBRAgent {
	private static String dataPath = "C:\\Users\\jan-o\\Documents\\";
	private static String projectName = "ProjektArbeitRommeNeu.prj";
	
	//myCBR
	private Project project;
	private Concept rommeConcept;
	private Retrieval retrieve;
	
	//Attribute von Romme
	private static IntegerDesc anzahlS1;
	private static IntegerDesc anzahlSpHand;
	private static IntegerDesc anzahlCpuHand;
	private static IntegerDesc anzahlS2;
	private static IntegerDesc entfernung;
	private static SymbolDesc aktion;
	
	
	public CBRAgent() {
		try {
			project = new Project(dataPath + projectName);
			Thread.sleep(2000);
			rommeConcept = project.getConceptByID("RommeConcept");
			
		} catch (Exception e) {
			System.err.println("DEBUG Projekt(pfad) konnte nicht gefunden werden");
			
		}
	}
	public static void main(String[] args) {
		String cpuHand = "9H,8K,2P,5P,9K,9Kr,9P,4Kr,5Kr,6Kr";
		String sFeld1 = "";
		String sFeld2 = "";
		String sFeld3 = "";
		String cpuFeld1 = "";
		String cpuFeld2 = "";
		String cpuFeld3 = "";
		boolean sR = false;
		boolean cpuR = false;
		
		String abwurfStapel = "13Kr";
		GameState gs = new GameState(10, sFeld1, sFeld2, sFeld3, sR,
			 cpuHand, cpuFeld1, cpuFeld2, cpuFeld3, cpuR, 
			  abwurfStapel);
		
		String antwort = zug(gs);
		boolean ziehen = ziehen(gs);
		if(ziehen) {
			System.out.println("forti");
		}
		System.out.println("Antwort:" + antwort);

	
	}
	
	//Funktionen die Rami aufruft:
	//hier noch gesamtwert einbauen, nächste nur ziehen wenn rausgelegt, ansonsten prüfen ob der potentielle wert >= 30 wäre oder man theoretisch rauslegen könnte
	public static boolean ziehen(GameState gs) {
		Romme romme = rommeErstellen(gs);
		Karten aufgedeckte = kartenListe(gs.getAbwurfStapel()).get(0);
		List<Karten> karten = kartenListe(gs.getCpuHand());
		sortiereKarten(karten);
		List<Sequenz> reihe = listeReihe(karten);
		List<Sequenz> folge = listeFolge(karten);
		List<Sequenz> cpuFelder = felderListe(gs.getCpuFeld1(), gs.getCpuFeld2(), gs.getCpuFeld3());
		List<Sequenz> spFelder = felderListe(gs.getSpielerFeld1(), gs.getSpielerFeld2(), gs.getSpielerFeld3());
		boolean ziehen = false;
		
	
		for (Sequenz r : reihe) {
			if (passtReihe(r.getKarten(), aufgedeckte)) {
				ziehen = true;
			}
		}
		for (Sequenz f : folge) {
			if (passtFolge(f.getKarten(), aufgedeckte) && !vorhanden(f.getKarten(), aufgedeckte)) {
				if (entfernung(f.getKarten(), aufgedeckte) == 1) {
					ziehen = true;
				} else {
					List<Pair<Instance, Similarity>> ergebnis;
					String zugaktion = "";
					CBRAgent agent = new CBRAgent();
					rommeUpdate(romme, f, 1, aufgedeckte);
					
					ergebnis = agent.startQuery(romme, 0);
					zugaktion = agent.aktion(ergebnis);
					
					if (zugaktion.equals("Ziehen")) {
						ziehen = true;
					} 
					
				}
			}
		}
		
		for (Sequenz cF: cpuFelder) {
			if(!cF.getKarten().isEmpty() && istReihe(cF.getKarten())) {
				if (passtReihe(cF.getKarten(), aufgedeckte)) {
					ziehen = true;
				}
			} else {
				if (!cF.getKarten().isEmpty() && passtFolge(cF.getKarten(), aufgedeckte) && !vorhanden(cF.getKarten(), aufgedeckte)) {
					if (entfernung(cF.getKarten(), aufgedeckte) == 1) {
						ziehen = true;
					} else {
						List<Pair<Instance, Similarity>> ergebnis;
						String zugaktion = "";
						CBRAgent agent = new CBRAgent();
						rommeUpdate(romme, cF, 1, aufgedeckte);
						
						ergebnis = agent.startQuery(romme, 0);
						zugaktion = agent.aktion(ergebnis);
						
						if (zugaktion.equals("Ziehen")) {
							ziehen = true;
						} 
						
					}
				}
			}
		}
		for (Sequenz sF: spFelder) {
			if(!sF.getKarten().isEmpty() && istReihe(sF.getKarten())) {
				if (passtReihe(sF.getKarten(), aufgedeckte)) {
					ziehen = true;
				}
			} else {
				if (!sF.getKarten().isEmpty() && passtFolge(sF.getKarten(), aufgedeckte) && !vorhanden(sF.getKarten(), aufgedeckte)) {
					if (entfernung(sF.getKarten(), aufgedeckte) == 1) {
						ziehen = true;
					} else {
						List<Pair<Instance, Similarity>> ergebnis;
						String zugaktion = "";
						CBRAgent agent = new CBRAgent();
						rommeUpdate(romme, sF, 1, aufgedeckte);
						
						ergebnis = agent.startQuery(romme, 0);
						zugaktion = agent.aktion(ergebnis);
						
						if (zugaktion.equals("Ziehen")) {
							ziehen = true;
						} 
						
					}
				}
			}
		}
		return ziehen;
	}
	public static String zug(GameState gs) {
		Romme romme = rommeErstellen(gs);
		List<Karten> karten = kartenListe(gs.getCpuHand());
		boolean rausgelegt = gs.getCpuRausgekommen();
		boolean wirdRauslegen = false;
		sortiereKarten(karten);
		List<Sequenz> cpuFelder = felderListe(gs.getCpuFeld1(), gs.getCpuFeld2(), gs.getCpuFeld3());
		List<Sequenz> spFelder = felderListe(gs.getSpielerFeld1(), gs.getSpielerFeld2(), gs.getSpielerFeld3());
		List<Karten> doppelte = doppelt(karten);
		List<Sequenz> reihen = listeReihe(karten);
		List<Sequenz> folgen = listeFolge(karten);
		List<Karten> aussortiert = new ArrayList<>();
		List<Karten> doppeltBenutzt = new ArrayList<>();
		List<Sequenz> potentiellR = new ArrayList<>();
		List<Sequenz> finalReihen = new ArrayList<>();
		List<Sequenz> finalFolgen = new ArrayList<>();
		List<Karten> entfernungsK = new ArrayList<>();
		String raus = "";
		String anlegen = "";
		String ablegen = "";
		
		
		doppelte = doppelt(karten);
		reihen = listeReihe(karten);
		folgen = listeFolge(karten);
		
		aufraeumen(reihen, aussortiert);
		aufraeumen(folgen, aussortiert);
		aufraeumen2(reihen, aussortiert);
		aufraeumen2(folgen, aussortiert);
		aufraeumen3(aussortiert, doppelte);
		sortiereKarten(aussortiert);
		doppeltBenutzt = doppeltVorhanden(karten, folgen, reihen);
		aufraeumen5(folgen, reihen, doppeltBenutzt, doppelte);
		
		if (!rausgelegt) {
			kannRauslegen(reihen, folgen, potentiellR);

			for (Sequenz s : potentiellR) {
				rauslegen(s, folgen, rausgelegt, aussortiert, finalFolgen, finalReihen,romme, wirdRauslegen, entfernungsK);			
			}
			
			if (wirdRauslegen) {
				for (Sequenz s : potentiellR) {
					rauslegen(s, folgen, true, aussortiert, finalFolgen, finalReihen,romme, wirdRauslegen, entfernungsK);
				}
			}
			raus = rauslegen(finalFolgen, finalReihen, cpuFelder);
			anlegen = anlegen(folgen, aussortiert, cpuFelder, spFelder, true);
			ablegen = ablegen(folgen, reihen, aussortiert, rausgelegt, entfernungsK);
			
		} else {
			kannRauslegen(reihen, folgen, potentiellR);
			for (Sequenz s: potentiellR) {
				System.out.println("Potent Karten:" + kartenString(s.getKarten()));
			}
			for (Sequenz s : potentiellR) {
				rauslegen(s, folgen, rausgelegt, aussortiert, finalFolgen, finalReihen,romme, wirdRauslegen, entfernungsK);
			}
			raus = rauslegen(finalFolgen, finalReihen, cpuFelder);
			anlegen = anlegen(folgen, aussortiert, cpuFelder, spFelder, rausgelegt);
			ablegen = ablegen(folgen, reihen, aussortiert, rausgelegt, entfernungsK);

		}
		
		String e = raus + anlegen + ablegen;
		
		
		return e;
	}
	
	//Funktionen myCbr:
	public  List<Pair<Instance, Similarity>> startQuery(Romme romme, int zug) {
		//␣Get␣the␣values␣of␣the␣request
		anzahlCpuHand = (IntegerDesc) this.rommeConcept.getAllAttributeDescs().get("Anzahl Cpuhandkarten");
		anzahlSpHand = (IntegerDesc) this.rommeConcept.getAllAttributeDescs().get("Anzahl Spielerhandkarten");
		anzahlS1 = (IntegerDesc) this.rommeConcept.getAllAttributeDescs().get("Anzahl Sequenz 1");
		anzahlS2 = (IntegerDesc) this.rommeConcept.getAllAttributeDescs().get("Anzahl Sequenz 2");
		entfernung = (IntegerDesc) this.rommeConcept.getAllAttributeDescs().get("Entfernung Sequenz 1 zu 2");
		aktion = (SymbolDesc) this.rommeConcept.getAllAttributeDescs().get("Zugaktion");
		
		try {
			ICaseBase casebase;
			if (zug == 0) {
				casebase = project.getCaseBases().get("casebase");
			} else {
				casebase = project.getCaseBases().get("casebase2");
			}
			
			retrieve = new Retrieval(rommeConcept, casebase);
			retrieve.setRetrievalMethod(RetrievalMethod.RETRIEVE_SORTED);
			Instance query = retrieve.getQueryInstance();
			query.addAttribute(anzahlCpuHand, anzahlCpuHand.getAttribute(romme.getAnzahlCpuHand()));
			query.addAttribute(anzahlSpHand, anzahlSpHand.getAttribute(romme.getAnzahlSpHand()));
			query.addAttribute(anzahlS1, anzahlS1.getAttribute(romme.getAnzahlS1()));
			query.addAttribute(anzahlS2, anzahlS2.getAttribute(romme.getAnzahlS2()));
			query.addAttribute(entfernung, entfernung.getAttribute(romme.getEntfernung()));
			//query.addAttribute(aktion, aktion.getAttribute(romme.getAktion())); Brauchen wir nicht, da Aktion nur antwort ist.
		} catch (ParseException e) {
			System.err.println("ERROR CBRAgent: Error bei query!");
		}

		//␣Send␣query
		retrieve.start();
		System.out.println("Query funzt");
		return retrieve.getResult();
	}
	public String aktion(List<Pair<Instance, Similarity>> ergebnis) {
		String zugAktion = "";
		Instance obj = rommeConcept.getInstance(ergebnis.get(0).getFirst().getName());
		zugAktion = obj.getAttForDesc(aktion).getValueAsString();
		
		
		return zugAktion;
	}
	
	
	
	public static String ablegen(List<Sequenz> folgen, List<Sequenz> reihen, List<Karten> aussortiert, boolean rausgelegt, List<Karten> entfernungsK) {
		String s = "";
		if(rausgelegt) {
			if(!aussortiert.isEmpty()) {
				s = "E:" + aussortiert.get(0).getWert() + aussortiert.get(0).getFarbe() + ";";
			} else {
				if(!entfernungsK.isEmpty()) {
					Karten weiteste = null;
					int entfernung = 0;
					for(Karten k: entfernungsK) {
						for(Sequenz se : folgen) {
							if(passtFolge(se.getKarten(),k)) {
								if(weiteste == null) {
									weiteste = k;
									entfernung = entfernung(se.getKarten(),k);
								} else {
									if(entfernung(se.getKarten(),k) > entfernung) {
										entfernung = entfernung(se.getKarten(),k);
									} else if(entfernung(se.getKarten(),k) == entfernung && k.getWert() > weiteste.getWert()) {
										weiteste = k;
									}
								}
							}
						}
					}
					s = "E:" + weiteste.getWert() + weiteste.getFarbe() + ";";
				} else {
					Karten groessteKarte = null;
		            for (Sequenz sr : reihen) {
		            	if (groessteKarte == null) {
		            		groessteKarte = sr.getKarten().get(0);
		            	} else {
		            		if(groessteKarte.getWert() < sr.getKarten().get(0).getWert()) {
		            			groessteKarte = sr.getKarten().get(0);
		            		}
		            	}
		            }
		            for (Sequenz sf : folgen) {
		              	if (groessteKarte == null) {
		              		groessteKarte = sf.getKarten().get(0);
		            	} else {
		            		if(groessteKarte.getWert() < sf.getKarten().get(0).getWert()) {
		            			groessteKarte = sf.getKarten().get(0);
		            		}
		            	}
		            }
		            s = "E:" + groessteKarte.getWert() + groessteKarte.getFarbe() + ";";
				}
			}
		} else {
			if(!aussortiert.isEmpty()) {
				if(aussortiert.size() > 1) {
					s = "E:" + aussortiert.get(aussortiert.size() - 1).getWert() + aussortiert.get(aussortiert.size() - 1).getFarbe() + ";";
				} else {
					s = "E:" + aussortiert.get(0).getWert() + aussortiert.get(0).getFarbe() + ";";
				}
			} else {
				if(!entfernungsK.isEmpty()) {
					Karten weiteste = null;
					int entfernung = 0;
					for(Karten k: entfernungsK) {
						for(Sequenz se : folgen) {
							if(passtFolge(se.getKarten(),k)) {
								if(weiteste == null) {
									weiteste = k;
									entfernung = entfernung(se.getKarten(),k);
								} else {
									if(entfernung(se.getKarten(),k) > entfernung) {
										entfernung = entfernung(se.getKarten(),k);
									} else if(entfernung(se.getKarten(),k) == entfernung && k.getWert() < weiteste.getWert()) {
										weiteste = k;
									}
								}
							}
						}
					}
					s = "E:" + weiteste.getWert() + weiteste.getFarbe() + ";";
				} else {
					Karten niedrigsteKarte = null;
		            for (Sequenz sr : reihen) {
		            	if (niedrigsteKarte == null) {
		            		niedrigsteKarte = sr.getKarten().get(0);
		            	} else {
		            		if(niedrigsteKarte.getWert() > sr.getKarten().get(0).getWert()) {
		            			niedrigsteKarte = sr.getKarten().get(0);
		            		}
		            	}
		            }
		            if (!folgen.isEmpty()) {
			            for(Sequenz sz : folgen) {
			            	System.out.println("Karten Folgen:" + kartenString(sz.getKarten()));
			            }
		            	for (Sequenz sf : folgen) {
			            	System.out.println("Out of bounds test hallo" + kartenString(sf.getKarten()));
			            	
			              	if (niedrigsteKarte == null) {
			            		niedrigsteKarte = sf.getKarten().get(0);
			            	} else {
			            		if(niedrigsteKarte.getWert() > sf.getKarten().get(0).getWert()) {
			            			niedrigsteKarte = sf.getKarten().get(0);
			            		}
			            	}
			            }
			            
		            }
	
		            s = "E:" + niedrigsteKarte.getWert() + niedrigsteKarte.getFarbe() + ";";
				}
			}
		}
		return s;
	}
	
	//Funktioniert für Sequenzen die komplett angelegt werden können, jedoch noch nicht für einen Bestandteil einer Sequenz
	public static String anlegen(List<Sequenz> folgen, List<Karten> aussortiert, List<Sequenz> cpuFelder, List<Sequenz> spFelder, boolean rausgelegt) {
		String anlegen = "";
		List<Sequenz> entfernen = new ArrayList<>();
		//Für die CPU Felder, Blick auf Folgen Bildung:
		for (Sequenz s : folgen) {
			for (int i = 0; i < cpuFelder.size(); i++) {
				if (!cpuFelder.get(i).getKarten().isEmpty() && !cpuFelder.get(i).getFarbe().equals("mixed") && cpuFelder.get(i).getKarten().get(0).getWert() == s.getKarten().get(s.getKarten().size() - 1) .getWert() + 1) {
					anlegen += "A:" + kartenString(s.getKarten()) + ",CPUFeld" + (i+1) + ";";
					entfernen.add(s);
					//folgen.remove(s);
				} else if (!cpuFelder.get(i).getKarten().isEmpty() && cpuFelder.get(i).getKarten().get(cpuFelder.get(i).getKarten().size() - 1).getWert() == s.getKarten().get(0) .getWert() - 1) {
					anlegen += "A:" + kartenString(s.getKarten()) + ",CPUFeld" + (i+1) + ";";
					//folgen.remove(s);
					entfernen.add(s);
				}
			}
		}
		for (Karten k : aussortiert) {
			for (int i = 0; i < cpuFelder.size(); i++) {
				if (!cpuFelder.get(i).getKarten().isEmpty() &&!cpuFelder.get(i).getFarbe().equals("mixed") && cpuFelder.get(i).getKarten().get(0).getWert() == k.getWert() + 1) {
					anlegen += "A:" + k.getWert() + k.getFarbe() + ",CPUFeld" + (i+1) + ";";
					aussortiert.remove(k);
				} else if (!cpuFelder.get(i).getKarten().isEmpty() && cpuFelder.get(i).getKarten().get(cpuFelder.get(i).getKarten().size() - 1).getWert() == k.getWert() - 1) {
					anlegen += "A:" + k.getWert() + k.getFarbe() + ",CPUFeld" + (i+1) + ";";
					aussortiert.remove(k);
				}
			}
		}
		//Für die Spieler Felder, Blick auf Folgen Bildung:
		for (Sequenz s : folgen) {
			for (int i = 0; i < spFelder.size(); i++) {
				if (!spFelder.get(i).getKarten().isEmpty() && !spFelder.get(i).getFarbe().equals("mixed") && spFelder.get(i).getKarten().get(0).getWert() == s.getKarten().get(s.getKarten().size() - 1) .getWert() + 1) {
					anlegen += "A:" + kartenString(s.getKarten()) + ",SpielerFeld" + (i+1) + ";";
					entfernen.add(s);
					//folgen.remove(s);
				} else if (!spFelder.get(i).getKarten().isEmpty() && !spFelder.get(i).getFarbe().equals("mixed") && spFelder.get(i).getKarten().get(spFelder.get(i).getKarten().size() - 1).getWert() == s.getKarten().get(0) .getWert() - 1) {
					anlegen += "A:" + kartenString(s.getKarten()) + ",SpielerFeld" + (i+1) + ";";
					entfernen.add(s);
					//folgen.remove(s);
				}
			}
		}
		for (Karten k : aussortiert) {
			for (int i = 0; i < spFelder.size(); i++) {
				if (!spFelder.get(i).getKarten().isEmpty() && !spFelder.get(i).getFarbe().equals("mixed") && spFelder.get(i).getKarten().get(0).getWert() == k.getWert() + 1) {
					anlegen += "A:" + k.getWert() + k.getFarbe() + ",SpielerFeld" + (i+1) + ";";
					aussortiert.remove(k);
				} else if (!spFelder.get(i).getKarten().isEmpty() && !spFelder.get(i).getFarbe().equals("mixed") && spFelder.get(i).getKarten().get(spFelder.get(i).getKarten().size() - 1).getWert() == k.getWert() - 1) {
					anlegen += "A:" + k.getWert() + k.getFarbe() + ",SpielerFeld" + (i+1) + ";";
					aussortiert.remove(k);
				}
			}
		}
		//Für Einzelkarten, Blick auf Reihen
		for (Karten k : aussortiert) {
			
			for (int i = 0; i < cpuFelder.size(); i++) {
				if(!cpuFelder.get(i).getKarten().isEmpty() && passtReihe(cpuFelder.get(i).getKarten(), k)) {
					anlegen += "A:" + k.getWert() + k.getFarbe() + ",CPUFeld" + (i+1) + ";";
				}
				
			}
			
			for (int j = 0; j < spFelder.size(); j++) {
				if(!spFelder.get(j).getKarten().isEmpty() && passtReihe(spFelder.get(j).getKarten(), k)) {
					anlegen += "A:" + k.getWert() + k.getFarbe() + ",SpielerFeld" + (j+1) + ";";
				}
				
			}
		}
		folgen.removeAll(entfernen);
		return anlegen ;
	}
	
	
	//Erstellen eines Rauslegen Strings für Rami
	public static String rauslegen(List<Sequenz> folgenFinal, List<Sequenz> reihenFinal, List<Sequenz> cpuFelder) { 
		String rauslegen = "";
		List<Sequenz> neu = new ArrayList<>();
		for(Sequenz s : folgenFinal) {
			System.out.println("Karten folgenF:" + kartenString(s.getKarten()));
		}
		for(Sequenz s : reihenFinal) {
			System.out.println("Karten reihenF:" + kartenString(s.getKarten()));
		}
		neu.addAll(folgenFinal);
		neu.addAll(reihenFinal);
		for(Sequenz s : neu) {
			System.out.println("Karten neu:" + kartenString(s.getKarten()));
		}
		for (Sequenz s : neu) {
			for(int i = 0; i < cpuFelder.size(); i++) {
				if(cpuFelder.get(i).getKarten().isEmpty()) {
					rauslegen += "S:" + kartenString(s.getKarten()) + ";";
					cpuFelder.set(i, s);
					break;
					
				}
			}
		}

		
		return rauslegen;
	}
	
	//Bestimmt ob eine Sequenz rausgelegt werden soll, fügt diese der rauslegenFinal hinzu
	public static void rauslegen(Sequenz potentielle, List<Sequenz> folgen, boolean rausgelegt, 
							List<Karten> aussortiert, List<Sequenz> rauslegenFinalFolgen, List<Sequenz> rauslegenFinalReihen, Romme romme, Boolean rauslegen, List<Karten> entfernungsK) {
		
		if(!rausgelegt) {
			if(potentielle.getGesamtWert() >= 30)  {
				rauslegen = supp(aussortiert, potentielle, romme, folgen, entfernungsK);
			} 		
		} else {
			rauslegen = supp(aussortiert, potentielle, romme, folgen, entfernungsK);
			
		}
		if(rauslegen) {
			if (potentielle.getFarbe().equals("mixed")) {
				rauslegenFinalReihen.add(potentielle);
			} else {
				rauslegenFinalFolgen.add(potentielle);
			}
		} 
		
	}
	
	//Unterstützungsfunktion für rauslegen(), bestimmt ob eine Sequenz rausgelegt werden soll 
	public static boolean supp(List<Karten> aussortiert, Sequenz potentielle, Romme romme, List<Sequenz> folgen, List<Karten> entfernungsK) {
		boolean rauslegen = false;
		if(!potentielle.getFarbe().equals("mixed")) {
			for (Karten k : aussortiert) {
				if(passtFolge(potentielle.getKarten(), k)) {
					rommeUpdate(romme, potentielle, 1, k);
		
					List<Pair<Instance, Similarity>> ergebnis;
					String zugaktion = "";
					CBRAgent agent = new CBRAgent();
					
					ergebnis = agent.startQuery(romme, 1);
					zugaktion = agent.aktion(ergebnis);
					if(zugaktion.equals("Rauslegen")) {
						rauslegen = true;
					} else {
						entfernungsK.add(k);
						aussortiert.remove(k);
					}
				}
			
			}
			for(Sequenz s : folgen) {
				
				if(passtFolge(potentielle.getKarten(), s.getKarten().get(0))) {
					if(potentielle.getKarten().get(0).getWert() > s.getKarten().get(0).getWert()) {
						rommeUpdate(romme, potentielle, s.getKartenAnzahl(), s.getKarten().get(s.getKartenAnzahl() - 1) );
						
						List<Pair<Instance, Similarity>> ergebnis;
						String zugaktion = "";
						CBRAgent agent = new CBRAgent();
						
						ergebnis = agent.startQuery(romme, 1);
						zugaktion = agent.aktion(ergebnis);
						if(zugaktion.equals("Rauslegen")) {
							rauslegen = true;
						}
						
					} else {
						rommeUpdate(romme, potentielle, s.getKartenAnzahl(), s.getKarten().get(0) );
						
						List<Pair<Instance, Similarity>> ergebnis;
						String zugaktion = "";
						CBRAgent agent = new CBRAgent();
						
						ergebnis = agent.startQuery(romme, 1);
						zugaktion = agent.aktion(ergebnis);
						if(zugaktion.equals("Rauslegen")) {
							rauslegen = true;
						}
					}
			
				}
			}
		} else {
			rauslegen = true;
			
		}
		return rauslegen;
	}
	
	//Alle Sequenzen die min 3 Karten beinhalten rausfiltern
	public static void kannRauslegen(List<Sequenz> reihen, List<Sequenz> folgen, List<Sequenz> potentiellRaus) {
	    for (Sequenz r : new ArrayList<>(reihen)) {
	        if (r.getKartenAnzahl() > 2) {
	            potentiellRaus.add(r);
	            reihen.remove(r);
	        }
	    }

	    for (Sequenz f : new ArrayList<>(folgen)) {
	        if (f.getKartenAnzahl() > 2) {
	            potentiellRaus.add(f);
	            folgen.remove(f);
	        }
	    }

	}

	
	
	public static void aufraeumen5(List<Sequenz> folgen, List<Sequenz> reihen, List<Karten> doppeltBenutzt, List<Karten> doppelt) {
		List<Sequenz> folgenEntf = new ArrayList<>();
		List<Sequenz> reihenEntf = new ArrayList<>();
		
		for (Karten k : doppeltBenutzt) {
	        for (Sequenz folge : folgen) {
	            for (int i = 0; i < folge.getKarten().size(); i++) {
	                Karten folgenKarte = folge.getKarten().get(i);
	                if (folgenKarte.equals(k)) {
	                    for (Sequenz reihe : reihen) {
	                        for (int j = 0; j < reihe.getKarten().size(); j++) {
	                            Karten reihenKarte = reihe.getKarten().get(j);
	                            if (reihenKarte.equals(k)) {
	                                if (folge.getKartenAnzahl() > reihe.getKartenAnzahl()) {
	                                    reihe.getKarten().remove(j);
	                                } else {
	                                    folge.getKarten().remove(i);
	                                }
	                            }
	                        }
	                        if(reihe.getKarten().isEmpty()) {
	                        	reihenEntf.add(reihe);
	                        }
	                    }
	                    
	                }
	            }
	            if(folge.getKarten().isEmpty()) {
	            	folgenEntf.add(folge);
	            }
	        }
	    }
		folgen.removeAll(folgenEntf);
		reihen.removeAll(reihenEntf);
	}
	
	public static void aufraeumen4(List<Karten> aussortiert, List<Karten> doppelte, List<Karten> doppeltBenutzt) {
		 for (Karten k : doppelte) {
		        
		        if (!vorhanden(doppeltBenutzt, k)) {
		            
		            aussortiert.add(k);
		        }
		 }
	}
	
	public static void aufraeumen3(List<Karten> aussortiert, List<Karten> doppelte) {
		int zaehler = 0;
		for(int i = 0; i < aussortiert.size(); i++) {
			zaehler++;
			Karten karte = aussortiert.get(i);
			
			for (int j = i; j < aussortiert.size(); j++) {
				if(karte.getFarbe().equals(aussortiert.get(j).getFarbe()) && karte.getWert() == aussortiert.get(j).getWert()) {
					zaehler++;
					if (zaehler > 3 && vorhanden(doppelte, aussortiert.get(j))) {
						aussortiert.remove(j);
						j--;
					} else if(zaehler > 2 && !vorhanden(doppelte,aussortiert.get(j))) {
						aussortiert.remove(j);
						j--;
					}
				}
			}
			zaehler = 0;
			
		}
	
	}
	            
	public static void aufraeumen2(List<Sequenz> sL, List<Karten> aussortiert) {
		for(Sequenz s: sL) {
			
			for (int i = aussortiert.size() - 1; i >= 0; i--) {
		        
		        if (vorhanden(s.getKarten(), aussortiert.get(i))) {
		            
		        	aussortiert.remove(i); 
		             
		        }
		    }
			
		}
		
	}
	
	public static void aufraeumen(List<Sequenz> sL, List<Karten> aussortiert) {
		
		for (int i = sL.size() - 1; i >= 0; i--) {
	        Sequenz s = sL.get(i);
	        if (sL.get(i).getKarten().size() == 1) {
	        	sL.remove(i);
	        	aussortiert.add(s.getKarten().get(0));
	  
	        }
	        
	    }		
	}
	
	
	
	public static List<Sequenz> felderListe(String feld1, String feld2, String feld3) {
		List<Sequenz> felderL = new ArrayList<>();
		List<Karten> f1 = kartenListe(feld1);
		List<Karten> f2 = kartenListe(feld2);
		List<Karten> f3 = kartenListe(feld3);
		Sequenz s1;
		Sequenz s2;
		Sequenz s3;
		
		
		
		if(feld1.equals("")) {
			s1 = new Sequenz("", 0, 0, f1);
			if(f1.isEmpty()) {
				
			}
		} else {
			s1 = new Sequenz(farbeBerechnen(f1),wertBerechnen(f1),anzahlBerechnen(f1),f1);
		}
		if(feld2.equals("")) {
			s2 = new Sequenz("", 0, 0, f2);
		} else {
			s2 = new Sequenz(farbeBerechnen(f2),wertBerechnen(f2),anzahlBerechnen(f2),f2);
		}
		if(feld3.equals("")) {
			s3 = new Sequenz("", 0, 0, f3);
		} else {
			s3 = new Sequenz(farbeBerechnen(f3),wertBerechnen(f3),anzahlBerechnen(f3),f3);
		}
		
		

		
		felderL.add(s1);
		felderL.add(s2);
		felderL.add(s3);
		
		
		
		return felderL;
	}
	
	
	
	public static void rommeUpdate(Romme romme, Sequenz folge, int anzahl2, Karten betrachtete) {
		romme.setAnzahlS1(folge.getKartenAnzahl());
		romme.setAnzahlS2(anzahl2);
		romme.setEntfernung(entfernung(folge.getKarten(), betrachtete));
		
	}
	
	
	public static Romme rommeErstellen(GameState gs) {
		
		int anzahlSpHand = gs.getSpielerHand();
		int anzahlCpuHand =  anzahlBerechnen(kartenListe(gs.getCpuHand()));
		Romme romme = new Romme(0,anzahlSpHand, anzahlCpuHand, 0, 0, "");
		
		return romme;
	}



	public static List<Karten> kartenListe(String handKarten) {
		String[] handKartenNeu = handKarten.split(",");
		List<Karten> karten = new ArrayList<>();
		if(!handKarten.equals("")) {
			for(int i = 0; i < handKartenNeu.length; i++) {
				int wert = 0;
				String farbe = "";
				String karteString = handKartenNeu[i];
				for (int j = 0; j < karteString.length(); j++) {
					char c = karteString.charAt(j);
			        if (Character.isDigit(c)) {
			        	wert = wert * 10 + Character.getNumericValue(c);
			        } else {
			            farbe += c;
			        }
			    }
				Karten karte = new Karten(wert, farbe);
				karten.add(karte);

			}
		} 

		return karten;
	}
	
	public static String kartenString(List<Karten> kartenListe) {
	    StringBuilder sb = new StringBuilder();
	    for (Karten karte : kartenListe) {
	        sb.append(karte.getWert()).append(karte.getFarbe()).append(",");
	    }
	    if (!kartenListe.isEmpty()) {
	        sb.deleteCharAt(sb.length() - 1);
	    }
	    return sb.toString();
	}
	
	
	// Beachte: keine korrekte Aussage zu size() = 1
	public static boolean istReihe(List<Karten> karten) {
		boolean r = false;
		if (!karten.isEmpty() && karten.size() >= 2 && karten.get(0).getWert() == karten.get(1).getWert()) {
			r = true;
		}
		return r;
	}
	
	//Sagt nur ob eine Karte zu einer Folge gehören könnte, diese Funktion muss mit Entfernung später benutzt werden
	public static boolean passtFolge(List<Karten> karten, Karten karte) {
		boolean passt = true;
		if (karten.get(0).getFarbe().equals(karte.getFarbe())) {
			for (int i = 0; i < karten.size(); i++) {
				if (karten.get(i).getWert() == karte.getWert()) {
					passt = false;
				}
			}
		} else {
			passt = false;
		}
		return passt;
	}
	
	public static boolean passtReihe(List<Karten> karten, Karten karte) {
		boolean passt = true;
		if(karte.getWert() == karten.get(0).getWert() && karten.size() < 4) {
			for (int i = 0; i < karten.size(); i++) {
				if(karte.getFarbe().equals(karten.get(i).getFarbe())) {
					passt = false;
				}
			}
		} else {
			passt = false;
		}
		return passt;
	}

	
	public static int entfernung(List<Karten> karten, Karten karte) {
	    Karten letzteKarte = karten.get(karten.size() - 1);
	    Karten ersteKarte = karten.get(0);
	    int entfernung = 0;
	    int ersterWert = ersteKarte.getWert();
	    int letzterWert = letzteKarte.getWert();

	    if(karte.getWert() < ersterWert) {
	    	if (karte.getWert() == 1) {
	    		int x = 0;
	    		int y = 0;
	    		x = ersterWert - karte.getWert();
	    		y = 13 - letzterWert;
	    		System.out.println("X:" + x);
	    		System.out.println("Y:" + y);
	    		if (x <= y) {
	    			entfernung = x;
	    		} else {
	    			entfernung = y;
	    		}
	    	} else {
	    		entfernung = ersterWert - karte.getWert();
	    	}
	    } else if(karte.getWert() > letzterWert) {
	    	entfernung = karte.getWert() - letzterWert;
	    }
	    return entfernung;
	}
	
	public static int wertBerechnen(List<Karten> karten) {
		boolean ass = false;
		boolean hoch = false;
		int wert = 0;
		for(int i = 0; i < karten.size(); i++) {
			if(karten.get(i).getWert() == 1) {
				ass = true;
			} else if(karten.get(i).getWert() == 13) {
				hoch = true;
			}
		}
		if(ass && hoch) {
			for(Karten karte : karten) {
				if(karte.getWert() == 1) {
					wert += 11;
				} else {
					if (karte.getWert() > 10) {
						wert += 10;
					} else {
						wert += karte.getWert();
					}
				}
			}
		} else {
			for(Karten karte : karten) {
				if (karte.getWert() > 10) {
					wert += 10;
				} else {
					wert += karte.getWert();
				}
			}
		}
		return wert;
	}
	
	public static String farbeBerechnen(List<Karten> karten) {
		String farbe = "";
		if(karten.get(0).getWert() != karten.get(1).getWert()) {
			farbe = karten.get(0).getFarbe();
		} else {
			farbe = "mixed";
		}
		return farbe;
	}
	
	public static int anzahlBerechnen(List<Karten> karten) {
		int anzahl = 0;
		for(int i = 0; i < karten.size(); i++) {
			anzahl += 1;
		}
		return anzahl;
	}
	// Ass mit einbauen fehlt
	public static List<Sequenz> listeFolge(List<Karten> karten) {
	    List<Sequenz> folge = new ArrayList<>();
	    List<Karten> neu = new ArrayList<>(karten);
	    for (int i = 0; i < neu.size(); i++) {
	        List<Karten> reihe = new ArrayList<>();
	        Karten aktuelleKarte = neu.get(i);
	        reihe.add(aktuelleKarte);
	        String farbe = aktuelleKarte.getFarbe();
	        int wert = aktuelleKarte.getWert();
	        int gesamtWert = wert; 
	        int anzahl = 0; 

	        for (int j = 0; j < neu.size(); j++) {
	            Karten naechsteKarte = neu.get(j);
	            if (farbe.equals(naechsteKarte.getFarbe()) && (wert == naechsteKarte.getWert() + 1 || wert == naechsteKarte.getWert() - 1) || (wert == 13 && naechsteKarte.getWert() == 1)) {
	                reihe.add(naechsteKarte);
	           
	                gesamtWert += naechsteKarte.getWert(); 
	                neu.remove(j);
	                j--;
	            } else if(reihe.size() > 1) {
	            	boolean hinzufuegen = false;
	            	for(Karten karte : reihe) {
	            		if(karte.getFarbe().equals(naechsteKarte.getFarbe()) && (karte.getWert() == naechsteKarte.getWert() + 1 || karte.getWert() == naechsteKarte.getWert() - 1)) {
	            			hinzufuegen = true;
	            		}
	            	}
	            	if(hinzufuegen) {
    	                reihe.add(naechsteKarte);
    	                gesamtWert += naechsteKarte.getWert(); 
    	                neu.remove(j);
    	                j--;
	            	}
	            }
	        }
	        if (!reihe.isEmpty()) {
	        	List<Karten> doppelt = new ArrayList<>();
	        	doppelt = doppelt(reihe);
	        	if (doppelt != null) {
	        		reihe.removeAll(doppelt);
	        		if (!doppelt.isEmpty()) {
	        			gesamtWert = wertBerechnen(doppelt);
	        			anzahl = anzahlBerechnen(doppelt);
		        		Sequenz d = new Sequenz(farbe, gesamtWert, anzahl, doppelt);
		        		folge.add(d);
	        		}
	        	}
	        	gesamtWert = wertBerechnen(reihe);
	        	anzahl = anzahlBerechnen(reihe);
	            Sequenz sequenz = new Sequenz(farbe, gesamtWert, anzahl, reihe);
	            sortiereSequenz(sequenz);
	            folge.add(sequenz); 
	        }
	    }
	    return folge;
	}
	    
	
	public static List<Sequenz> listeReihe(List<Karten> karten) {
	    List<Sequenz> gleicheW = new ArrayList<>();
	    List<Karten> neu = new ArrayList<>(karten);
	    for (int i = 0; i < neu.size(); i++) {
	        List<Karten> reihe = new ArrayList<>();
	        Karten aktuelleKarte = neu.get(i);
	        reihe.add(aktuelleKarte);
	        String farbe = aktuelleKarte.getFarbe();
	        int wert = aktuelleKarte.getWert();
	        int gesamtWert = 0; 
	        int anzahl = 0; 
	        
	        for (int j = i; j < neu.size(); j++) {
	            Karten nächsteKarte = neu.get(j);
	            if (!farbe.equals(nächsteKarte.getFarbe()) && wert == nächsteKarte.getWert()) {
	                reihe.add(nächsteKarte);
	                neu.remove(j);
	                j--;
	            }
	        }
	        
	        if (!reihe.isEmpty()) {
	        	List<Karten> doppelt = new ArrayList<>();
	        	doppelt = doppelt(reihe);
	        	if (doppelt != null) {
	        		reihe.removeAll(doppelt);
	        		if (!doppelt.isEmpty()) {
	        			gesamtWert = wertBerechnen(doppelt);
	        			anzahl = anzahlBerechnen(doppelt);
		        		Sequenz d = new Sequenz("mixed", gesamtWert, anzahl, doppelt);
		        		gleicheW.add(d);
	        		}
	        	}
    			gesamtWert = wertBerechnen(reihe);
    			anzahl = anzahlBerechnen(reihe);
	            Sequenz sequenz = new Sequenz("mixed", gesamtWert, anzahl, reihe);
	            gleicheW.add(sequenz);
	        }
	    }
	    return gleicheW;
	}
	
    public static void sortiereSequenz(Sequenz sequenz) {
        List<Karten> karten = sequenz.getKarten();
        karten.sort((karte1, karte2) -> Integer.compare(karte1.getWert(), karte2.getWert()));
        sequenz.setKarten(karten);
    }
    
    public static void sortiereKarten(List<Karten> karten) {
    	karten.sort((karte1, karte2) -> Integer.compare(karte2.getWert(), karte1.getWert())); 
    }
    
	public static boolean vorhanden(List<Karten> karten, Karten karte) {
		boolean vorhanden = false;
		for (int i = 0; i < karten.size(); i++) {
			if(karten.get(i).getFarbe().equals(karte.getFarbe()) && karten.get(i).getWert() == karte.getWert()) {
				vorhanden = true;
				break;
			}
		}
		return vorhanden;
	}
	
	public static boolean folgeUreihe(List<Sequenz> folgen, List<Sequenz> reihen, Karten karte) {
		boolean inFolge = false;
		boolean inReihe = false;
		boolean inBeidem = false;
		
		for(Sequenz s: folgen) {
			if (vorhanden(s.getKarten(), karte)) {
				inFolge = true;
				break;
			}
		}
		for(Sequenz s: reihen) {
			if (vorhanden(s.getKarten(), karte)) {
				inReihe = true;
				break;
			}
		}
		if (inFolge && inReihe) {
			inBeidem = true;
		}
		
		return inBeidem;
	}
	
	
	public static List<Karten> doppeltVorhanden(List<Karten> karten, List<Sequenz> folgen, List<Sequenz> reihen) {
		List<Karten> neu = new ArrayList<>();
	
		for(Karten k: karten) {
			boolean vorhanden1 = false;
			boolean vorhanden2 = false;
			for(Sequenz s: folgen) {
				if(vorhanden(s.getKarten(),k)) {
					vorhanden1 = true;
				}
			}
			for(Sequenz s2: reihen) {
				if(vorhanden(s2.getKarten(),k)) {
					vorhanden2 = true;
				}
			}
			if(vorhanden1 && vorhanden2) {
				neu.add(k);
			}
		}
		return neu;
	}
	
	public static List<Karten> doppelt(List<Karten> karten) {
		List<Karten> doppelte = new ArrayList<>();
		List<Karten> neu = new ArrayList<>(karten);
		for (int i = 0; i < neu.size(); i++) {
			Karten karte = neu.get(i);
			for (int j = i + 1; j < neu.size(); j++) {
				Karten karte2 = neu.get(j);
				if (karte.getFarbe().equals(karte2.getFarbe()) && karte.getWert() == karte2.getWert()) {
					doppelte.add(karte);
					neu.remove(j);
				}
			}
		}
		
		
		return doppelte;
	}

	
	/*List<Karten> karten = new ArrayList<>();
	List<Karten> doppelte = new ArrayList<>();
	List<Sequenz> reihen = new ArrayList<>();
	String test = "9H,8K,10H,2P,3P,4P,5P,8H,9H,9K,10K,10P,11P,12P,13P,1P";
	
	List<Karten> testK = new ArrayList<>();
	Karten k1 = new Karten(5,"H");
	Karten k2 = new Karten(6,"H");
	Karten k3 = new Karten(7,"H");
	Karten k4 = new Karten(1, "H");
	testK.add(k1);
	testK.add(k2);
	testK.add(k3);
	
	System.out.println("Entfernung:" + entfernung(testK, k4));

	karten = kartenListe(test);
	//for (Karten karte : karten) {
	//	System.out.println("Wert:" + karte.getWert() + ", Farbe:" + karte.getFarbe());
	//}
	sortiereKarten(karten);
	
	doppelte = doppelt(karten);
	reihen = listeReihe(karten);
	/*for (Sequenz sequenz : reihen) {
		System.out.println("Entfernung" + entfernung(sequenz.getKarten(), karte1));
		System.out.println("Sequenz Wert:" + sequenz.getGesamtWert() + "Anzahl:" + sequenz.getKartenAnzahl());
		for (Karten karte : sequenz.getKarten()) {
			System.out.println("Wert:" + karte.getWert() + ", Farbe:" + karte.getFarbe());
		}
		
		
		adad
				if(aussortiert.size() == 0) {
			ablegen += aussortiert.get(0).getWert() + aussortiert.get(0).getFarbe();
		} else if(aussortiert.size() > 1) {
			if (kartenAnzahl == 11) {
				ablegen += aussortiert.get(aussortiert.size() - 1);
			} else {
				ablegen += aussortiert.get(0);
			}
		} else {
			
		______________________________
	*/
	
}

