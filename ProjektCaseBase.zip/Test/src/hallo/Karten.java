package hallo;

public class Karten {
	private int wert;
	private String farbe;
	
	public Karten(int wert, String farbe) {
		this.wert = wert;
		this.farbe = farbe;
	}

	public int getWert() {
		return wert;
	}

	public void setWert(int wert) {
		this.wert = wert;
	}

	public String getFarbe() {
		return farbe;
	}

	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}

}
