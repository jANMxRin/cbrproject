package hallo;

import java.util.ArrayList;
import java.util.List;

public class Sequenz {
	private String farbe;
	private List<Karten> karten = new ArrayList<>();
	private int gesamtWert;
	private int kartenAnzahl;
	
	
	public Sequenz(String farbe,int gesamtWert, int kartenAnzahl, List<Karten> karten) {
		this.farbe = farbe;
		this.gesamtWert = gesamtWert;
		this.karten = karten;
		this.kartenAnzahl = kartenAnzahl;
	}

	public String getFarbe() {
		return farbe;
	}

	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}

	public List<Karten> getKarten() {
		return karten;
	}

	public void setKarten(List<Karten> karten) {
		this.karten = karten;
	}

	public int getGesamtWert() {
		return gesamtWert;
	}

	public void setGesamtWert(int gesamtWert) {
		this.gesamtWert = gesamtWert;
	}

	public int getKartenAnzahl() {
		return kartenAnzahl;
	}

	public void setKartenAnzahl(int kartenAnzahl) {
		this.kartenAnzahl = kartenAnzahl;
	}
	

}
