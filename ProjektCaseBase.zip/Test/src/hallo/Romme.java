package hallo;



public class Romme {
	private int anzahlS1;
	private int anzahlSpHand;
	private int anzahlCpuHand;
	private int anzahlS2;
    private int entfernung;
	private String aktion;
	private double aehnlichkeit;
	
	public String getAktion() {
		return aktion;
	}

	public void setAktion(String aktion) {
		this.aktion = aktion;
	}

	public double getAehnlichkeit() {
		return aehnlichkeit;
	}

	public void setAehnlichkeit(double aehnlichkeit) {
		this.aehnlichkeit = aehnlichkeit;
	}

	public Romme(int anzahlS1, int anzahlSpHand, 
			int anzahlCpuHand, int anzahlS2,
			int entfernung, String aktion) {
		
		this.anzahlS1 = anzahlS1;
		this.anzahlS2 = anzahlS2;
		this.anzahlCpuHand = anzahlCpuHand;
		this.anzahlSpHand = anzahlSpHand;
		this.entfernung = entfernung;
		this.aktion = aktion;
	
	}

	public int getAnzahlS1() {
		return anzahlS1;
	}

	public void setAnzahlS1(int anzahlS1) {
		this.anzahlS1 = anzahlS1;
	}

	public int getAnzahlSpHand() {
		return anzahlSpHand;
	}

	public void setAnzahlSpHand(int anzahlSpHand) {
		this.anzahlSpHand = anzahlSpHand;
	}

	public int getAnzahlCpuHand() {
		return anzahlCpuHand;
	}

	public void setAnzahlCpuHand(int anzahlCpuHand) {
		this.anzahlCpuHand = anzahlCpuHand;
	}

	public int getAnzahlS2() {
		return anzahlS2;
	}

	public void setAnzahlS2(int anzahlS2) {
		this.anzahlS2 = anzahlS2;
	}


	public int getEntfernung() {
		return entfernung;
	}

	public void setEntfernung(int entfernung) {
		this.entfernung = entfernung;
	}


	

}
